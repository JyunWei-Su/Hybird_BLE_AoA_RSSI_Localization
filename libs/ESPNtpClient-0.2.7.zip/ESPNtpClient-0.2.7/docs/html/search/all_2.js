var searchData=
[
  ['basicexample_2ecpp_0',['basicExample.cpp',['../basicExample_8cpp.html',1,'']]],
  ['begin_1',['begin',['../classNTPClient.html#a97358f6df5a00b0faa2bab288aef5d25',1,'NTPClient']]]
];
