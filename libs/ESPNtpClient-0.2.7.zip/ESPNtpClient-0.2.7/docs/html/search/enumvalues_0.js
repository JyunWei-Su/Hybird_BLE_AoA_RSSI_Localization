var searchData=
[
  ['accuracyerror_0',['accuracyError',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152ad7b34aa1ebe2a19c2c7de4844e8b4862',1,'NTPEventTypes.h']]]
];
