var searchData=
[
  ['ntp_5ftimeout_0',['NTP_TIMEOUT',['../advancedExample_8cpp.html#a576b30e69bec539d7c7838cad785b324',1,'NTP_TIMEOUT():&#160;advancedExample.cpp'],['../main_8cpp.html#a576b30e69bec539d7c7838cad785b324',1,'NTP_TIMEOUT():&#160;main.cpp']]]
];
