var searchData=
[
  ['s_5fgettimeloop_0',['s_getTimeloop',['../classNTPClient.html#ae5938be217bf64dc9c7a6ac5c7b2ae8e',1,'NTPClient']]],
  ['s_5fprocessrequesttimeout_1',['s_processRequestTimeout',['../classNTPClient.html#a373aaf50ea58f2ec37294d3d5367d6f3',1,'NTPClient']]],
  ['s_5freceivertask_2',['s_receiverTask',['../classNTPClient.html#ab021ae25855afd8db87da54710da8a94',1,'NTPClient']]],
  ['s_5frecvpacket_3',['s_recvPacket',['../classNTPClient.html#a2fa2b6079e4b109bd333becdc8051ffa',1,'NTPClient']]],
  ['sendntppacket_4',['sendNTPpacket',['../classNTPClient.html#a399b5e39488cdded7bbaa463bef83679',1,'NTPClient']]],
  ['setinterval_5',['setInterval',['../classNTPClient.html#a5a5af6cf67cc17ffb8aff993b92b4d64',1,'NTPClient::setInterval(int interval)'],['../classNTPClient.html#af69d3c09e0be124c83f28c8a742d5577',1,'NTPClient::setInterval(int shortInterval, int longInterval)']]],
  ['setmaxnumsyncretry_6',['setMaxNumSyncRetry',['../classNTPClient.html#a743d9984993cd7452a6b90f8aeb061fe',1,'NTPClient']]],
  ['setminsyncaccuracy_7',['setMinSyncAccuracy',['../classNTPClient.html#a08ce88f6a0a9d9d7fb31eae498749bb0',1,'NTPClient']]],
  ['setntpservername_8',['setNtpServerName',['../classNTPClient.html#abbac932eaa34d134c37aa25985b9b74f',1,'NTPClient']]],
  ['setntptimeout_9',['setNTPTimeout',['../classNTPClient.html#a383b170d7fe6ad465e17dd5c24708f21',1,'NTPClient']]],
  ['setnumaverounds_10',['setnumAveRounds',['../classNTPClient.html#ac973596693ad12bc9a33a6a365d2a9ea',1,'NTPClient']]],
  ['settimesyncthreshold_11',['settimeSyncThreshold',['../classNTPClient.html#a5cc469c30606116c8d2d2ad5043af0cb',1,'NTPClient']]],
  ['settimezone_12',['setTimeZone',['../classNTPClient.html#a2f03ad70e80f516146222bbe60da1475',1,'NTPClient']]],
  ['setup_13',['setup',['../advancedExample_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;advancedExample.cpp'],['../basicExample_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;basicExample.cpp'],['../ledFlasher_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;ledFlasher.cpp'],['../main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;main.cpp']]],
  ['stop_14',['stop',['../classNTPClient.html#ac9f9667304aec04e1a6973f32b544726',1,'NTPClient']]],
  ['syncstatus_15',['syncStatus',['../classNTPClient.html#a1e08ee8ebd545f81f81d19e1ead5244f',1,'NTPClient']]]
];
