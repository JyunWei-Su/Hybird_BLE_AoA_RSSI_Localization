var searchData=
[
  ['requestsent_0',['requestSent',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a51e0370b8b68533dc5522a397dd3ee7e',1,'NTPEventTypes.h']]],
  ['responseerror_1',['responseError',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a044d7bd6ef21be6dee8e32423ca69f7c',1,'NTPEventTypes.h']]]
];
