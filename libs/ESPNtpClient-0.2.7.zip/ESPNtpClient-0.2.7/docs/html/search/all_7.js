var searchData=
[
  ['getdatestr_0',['getDateStr',['../classNTPClient.html#aea888ea02ebab346c688071bcac369d7',1,'NTPClient::getDateStr()'],['../classNTPClient.html#a4672b71072cbfcdf0d75dc844a37e7de',1,'NTPClient::getDateStr(timeval moment)'],['../classNTPClient.html#a2b888d2e339eb60aa08d8eb1c991b570',1,'NTPClient::getDateStr(time_t moment)']]],
  ['getfirstsync_1',['getFirstSync',['../classNTPClient.html#a804e5322968c52b5b2e48b81e5b49567',1,'NTPClient']]],
  ['getfirstsyncus_2',['getFirstSyncUs',['../classNTPClient.html#a67e8ed036910e2d1b759f6c4bbb26566',1,'NTPClient']]],
  ['getinterval_3',['getInterval',['../classNTPClient.html#aaddfefb13c8de737c63f89d46d5386e5',1,'NTPClient']]],
  ['getlastntpsync_4',['getLastNTPSync',['../classNTPClient.html#a58c7f76a980abb0eae66262f83206960',1,'NTPClient']]],
  ['getlastntpsyncus_5',['getLastNTPSyncUs',['../classNTPClient.html#a69a5f48f5f00cafaea54267bd80d3169',1,'NTPClient']]],
  ['getlonginterval_6',['getLongInterval',['../classNTPClient.html#ab8eca0e89d94ea7fb85e9b87c2be667d',1,'NTPClient']]],
  ['getntpservername_7',['getNtpServerName',['../classNTPClient.html#a9b34334f6d49d900d5711850f61cb93d',1,'NTPClient']]],
  ['getnumaverounds_8',['getnumAveRounds',['../classNTPClient.html#a34b408b37dd80c5a85fc71408e5aab12',1,'NTPClient']]],
  ['getshortinterval_9',['getShortInterval',['../classNTPClient.html#aa03b14e52db7517b7af4af6cc9377cb5',1,'NTPClient']]],
  ['gettime_10',['getTime',['../classNTPClient.html#a943007de4fd489ce8a2a0bd6e7f137e4',1,'NTPClient']]],
  ['gettimedatestring_11',['getTimeDateString',['../classNTPClient.html#a4384f5b1e9b9c7b147d33da16202c0a5',1,'NTPClient::getTimeDateString()'],['../classNTPClient.html#a39328124b02ed1a6b97bae1292f1cacc',1,'NTPClient::getTimeDateString(timeval moment, const char *format=&quot;%02d/%02m/%04Y %02H:%02M:%02S&quot;)'],['../classNTPClient.html#af49037cf2ea8bf5673707dcba5047b2a',1,'NTPClient::getTimeDateString(time_t moment, const char *format=&quot;%02d/%02m/%04Y %02H:%02M:%02S&quot;)']]],
  ['gettimedatestringforjs_12',['getTimeDateStringForJS',['../classNTPClient.html#a6b145b108d700dca337126589e86399c',1,'NTPClient']]],
  ['gettimedatestringus_13',['getTimeDateStringUs',['../classNTPClient.html#afbc9cc01ca7558c72c754e2cc633e7e7',1,'NTPClient']]],
  ['gettimestr_14',['getTimeStr',['../classNTPClient.html#a7536006eadfe856eabcf92ca4e404368',1,'NTPClient::getTimeStr()'],['../classNTPClient.html#a878e1dabf5993eabb474e36c9c2ddfc6',1,'NTPClient::getTimeStr(timeval moment)'],['../classNTPClient.html#a5648c0a87cbfaf7b3ed0e6bb8df424c8',1,'NTPClient::getTimeStr(time_t moment)']]],
  ['getuptime_15',['getUptime',['../classNTPClient.html#afd7646fb66c621f58686410b380f8322',1,'NTPClient']]],
  ['getuptimestring_16',['getUptimeString',['../classNTPClient.html#a9e27a96fb803b56bdb314875b354ec94',1,'NTPClient']]]
];
