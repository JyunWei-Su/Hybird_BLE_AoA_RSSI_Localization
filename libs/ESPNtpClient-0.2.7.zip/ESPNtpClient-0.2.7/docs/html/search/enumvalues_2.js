var searchData=
[
  ['invalidaddress_0',['invalidAddress',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a6d9b6183ea430f1e3a851ac72fe5cbb0',1,'NTPEventTypes.h']]],
  ['invalidport_1',['invalidPort',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152ae9873bca412f27726f2385a0f15f257b',1,'NTPEventTypes.h']]]
];
