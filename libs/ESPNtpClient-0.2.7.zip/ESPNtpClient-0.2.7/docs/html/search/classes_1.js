var searchData=
[
  ['timestamp32_5ft_0',['timestamp32_t',['../structtimestamp32__t.html',1,'']]],
  ['timestamp64_5ft_1',['timestamp64_t',['../structtimestamp64__t.html',1,'']]]
];
