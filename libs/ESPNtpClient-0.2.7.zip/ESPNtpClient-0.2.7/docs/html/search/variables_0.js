var searchData=
[
  ['actualinterval_0',['actualInterval',['../classNTPClient.html#aafe59edef4ec020afdb1c9fd590e9834',1,'NTPClient']]]
];
