var searchData=
[
  ['begin_0',['begin',['../classNTPClient.html#a97358f6df5a00b0faa2bab288aef5d25',1,'NTPClient']]]
];
