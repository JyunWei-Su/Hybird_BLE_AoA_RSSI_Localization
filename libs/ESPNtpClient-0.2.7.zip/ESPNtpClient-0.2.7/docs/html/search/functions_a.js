var searchData=
[
  ['onntpsyncevent_0',['onNTPSyncEvent',['../classNTPClient.html#a7321eb7eab07ccf544f317fac9b6a0e2',1,'NTPClient']]],
  ['onwifievent_1',['onWifiEvent',['../advancedExample_8cpp.html#ad7801276fcdd6c02f1580b3bfee71c1d',1,'onWifiEvent(WiFiEvent_t event):&#160;advancedExample.cpp'],['../main_8cpp.html#ad7801276fcdd6c02f1580b3bfee71c1d',1,'onWifiEvent(WiFiEvent_t event):&#160;main.cpp']]]
];
