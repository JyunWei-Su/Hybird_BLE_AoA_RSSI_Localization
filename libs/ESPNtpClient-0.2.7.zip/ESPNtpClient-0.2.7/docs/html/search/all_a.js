var searchData=
[
  ['main_2ecpp_0',['main.cpp',['../main_8cpp.html',1,'']]],
  ['managewifi_1',['manageWifi',['../classNTPClient.html#aff6f36538b87638353ab207a8c7014ff',1,'NTPClient']]],
  ['max_5foffset_5faverage_5frounds_2',['MAX_OFFSET_AVERAGE_ROUNDS',['../ESPNtpClient_8h.html#aef0c55f99427089b497d711c1f356f6a',1,'ESPNtpClient.h']]],
  ['maxdispersionerrors_3',['maxDispersionErrors',['../classNTPClient.html#ae0ade91d375e30945739b542c42be433',1,'NTPClient']]],
  ['maxnumsyncretry_4',['maxNumSyncRetry',['../classNTPClient.html#a7e34b4dbe85e79377460e641b1cbc1c8',1,'NTPClient']]],
  ['micros_5',['micros',['../classNTPClient.html#a07f05d945cfaf52640446ae9e2acf51a',1,'NTPClient']]],
  ['millis_6',['millis',['../classNTPClient.html#a10a5db32e37a13a7ccc4c7fa0db1ba5f',1,'NTPClient']]],
  ['min_5fntp_5finterval_7',['MIN_NTP_INTERVAL',['../ESPNtpClient_8h.html#ac6b173ed97582fa3df0b764c9fcf1456',1,'ESPNtpClient.h']]],
  ['min_5fntp_5ftimeout_8',['MIN_NTP_TIMEOUT',['../ESPNtpClient_8h.html#a4225ca4c9809b1c8090f94eec14785e4',1,'ESPNtpClient.h']]],
  ['minsyncaccuracyus_9',['minSyncAccuracyUs',['../classNTPClient.html#a366c8c3eb61ba2ada1e8ad8e368e8f26',1,'NTPClient']]],
  ['mode_10',['mode',['../structNTPFlags__t.html#afefa4829c9695778449968eb49877ed6',1,'NTPFlags_t']]]
];
