var searchData=
[
  ['errorsending_0',['errorSending',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152ac06aaa57cac54353be73a9da80d3c5eb',1,'NTPEventTypes.h']]]
];
