var searchData=
[
  ['ntp_0',['NTP',['../ESPNtpClient_8cpp.html#a10953f00acc9c54a2371691d10e32a57',1,'NTP():&#160;ESPNtpClient.cpp'],['../ESPNtpClient_8h.html#a10953f00acc9c54a2371691d10e32a57',1,'NTP():&#160;ESPNtpClient.cpp']]],
  ['ntp_5fpacket_5fsize_1',['NTP_PACKET_SIZE',['../ESPNtpClient_8h.html#a79dcb9747083bff5ee2ed05247f5e094',1,'ESPNtpClient.h']]],
  ['ntpevent_2',['ntpEvent',['../advancedExample_8cpp.html#afda0e57d1eef1a218a44397c29a88885',1,'ntpEvent():&#160;advancedExample.cpp'],['../ledFlasher_8cpp.html#afda0e57d1eef1a218a44397c29a88885',1,'ntpEvent():&#160;ledFlasher.cpp'],['../main_8cpp.html#afda0e57d1eef1a218a44397c29a88885',1,'ntpEvent():&#160;main.cpp']]],
  ['ntprequested_3',['ntpRequested',['../classNTPClient.html#aa3f352b106fd1c948f850dd141352e5a',1,'NTPClient']]],
  ['ntpserver_4',['ntpServer',['../advancedExample_8cpp.html#a752895aa06a97c3166e73ef25b2135ef',1,'ntpServer():&#160;advancedExample.cpp'],['../ledFlasher_8cpp.html#a752895aa06a97c3166e73ef25b2135ef',1,'ntpServer():&#160;ledFlasher.cpp'],['../main_8cpp.html#a752895aa06a97c3166e73ef25b2135ef',1,'ntpServer():&#160;main.cpp']]],
  ['ntpserveripaddress_5',['ntpServerIPAddress',['../classNTPClient.html#ab166bde13addb2bbe840ef41832dc321',1,'NTPClient']]],
  ['ntpservername_6',['ntpServerName',['../classNTPClient.html#a16c1d51a7e29bc38f336f7c54bc9d148',1,'NTPClient']]],
  ['ntptimeout_7',['ntpTimeout',['../classNTPClient.html#a2a29ceecad7c04618e73d41a78674418',1,'NTPClient']]],
  ['ntpundecodedpacket_5ft_8',['NTPUndecodedPacket_t',['../ESPNtpClient_8cpp.html#aaacab2c3d11b1c71ca873492349f57d7',1,'ESPNtpClient.cpp']]],
  ['numaverounds_9',['numAveRounds',['../classNTPClient.html#a0ed6c825e85671f0a467c76815d432ba',1,'NTPClient']]],
  ['numdispersionerrors_10',['numDispersionErrors',['../classNTPClient.html#ada5f5c0c770ec3d890197ecf8cc0ea9c',1,'NTPClient']]],
  ['numsyncretry_11',['numSyncRetry',['../classNTPClient.html#ac9beb9ce0f4525ee10cf46b4798ec1fa',1,'NTPClient']]],
  ['numtimeouts_12',['numTimeouts',['../classNTPClient.html#a4d30a736f98884eb43d50f5432881f76',1,'NTPClient']]]
];
