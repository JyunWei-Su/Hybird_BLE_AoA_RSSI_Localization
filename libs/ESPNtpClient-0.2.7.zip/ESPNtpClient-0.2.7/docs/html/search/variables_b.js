var searchData=
[
  ['receive_0',['receive',['../structNTPPacket__t.html#a1d7673bb56c21641c0d318fc5283e263',1,'NTPPacket_t']]],
  ['receivertimer_1',['receiverTimer',['../classNTPClient.html#a4bad124820a37328802e1b5c7ff49257',1,'NTPClient']]],
  ['reference_2',['reference',['../structNTPPacket__t.html#aaf545dc284bbb7f905871882e7240a76',1,'NTPPacket_t']]],
  ['refid_3',['refID',['../structNTPPacket__t.html#af309052ae572f15f7c2cc00c61ceefdc',1,'NTPPacket_t']]],
  ['responsepacketvalid_4',['responsePacketValid',['../classNTPClient.html#a8955c5cfd30a0181d245ee1e3d9d4e8d',1,'NTPClient']]],
  ['responsetimer_5',['responseTimer',['../classNTPClient.html#a504d3373951a9581a2933b3a5f8c8dab',1,'NTPClient']]],
  ['retrials_6',['retrials',['../structNTPSyncEventInfo__t.html#a39831bffb7c7d8760ba0861c531ecbc8',1,'NTPSyncEventInfo_t']]],
  ['rootdelay_7',['rootDelay',['../structNTPPacket__t.html#ac2b05e6f4184dbb9ae8b246192ffc398',1,'NTPPacket_t']]],
  ['round_8',['round',['../classNTPClient.html#a41a87dbc6555a2605058f9ec89969565',1,'NTPClient']]]
];
