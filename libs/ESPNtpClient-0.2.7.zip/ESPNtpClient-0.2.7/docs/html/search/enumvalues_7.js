var searchData=
[
  ['timesyncd_0',['timeSyncd',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a405f059fceb5c3f5f9bf762b28313dff',1,'NTPEventTypes.h']]]
];
