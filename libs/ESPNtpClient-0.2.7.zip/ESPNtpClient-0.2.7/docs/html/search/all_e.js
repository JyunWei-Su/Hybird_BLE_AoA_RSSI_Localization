var searchData=
[
  ['readme_2emd_0',['readme.md',['../readme_8md.html',1,'']]],
  ['receive_1',['receive',['../structNTPPacket__t.html#a1d7673bb56c21641c0d318fc5283e263',1,'NTPPacket_t']]],
  ['receivertimer_2',['receiverTimer',['../classNTPClient.html#a4bad124820a37328802e1b5c7ff49257',1,'NTPClient']]],
  ['reference_3',['reference',['../structNTPPacket__t.html#aaf545dc284bbb7f905871882e7240a76',1,'NTPPacket_t']]],
  ['refid_4',['refID',['../structNTPPacket__t.html#af309052ae572f15f7c2cc00c61ceefdc',1,'NTPPacket_t']]],
  ['requestsent_5',['requestSent',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a51e0370b8b68533dc5522a397dd3ee7e',1,'NTPEventTypes.h']]],
  ['responseerror_6',['responseError',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a044d7bd6ef21be6dee8e32423ca69f7c',1,'NTPEventTypes.h']]],
  ['responsepacketvalid_7',['responsePacketValid',['../classNTPClient.html#a8955c5cfd30a0181d245ee1e3d9d4e8d',1,'NTPClient']]],
  ['responsetimer_8',['responseTimer',['../classNTPClient.html#a504d3373951a9581a2933b3a5f8c8dab',1,'NTPClient']]],
  ['retrials_9',['retrials',['../structNTPSyncEventInfo__t.html#a39831bffb7c7d8760ba0861c531ecbc8',1,'NTPSyncEventInfo_t']]],
  ['rootdelay_10',['rootDelay',['../structNTPPacket__t.html#ac2b05e6f4184dbb9ae8b246192ffc398',1,'NTPPacket_t']]],
  ['round_11',['round',['../classNTPClient.html#a41a87dbc6555a2605058f9ec89969565',1,'NTPClient']]]
];
