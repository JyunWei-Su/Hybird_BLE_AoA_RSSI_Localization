var searchData=
[
  ['ntpevent2str_0',['ntpEvent2str',['../classNTPClient.html#ad5e7080156ce027d0b8686fce645e14c',1,'NTPClient']]]
];
