var searchData=
[
  ['lastntpresponsepacket_0',['lastNtpResponsePacket',['../classNTPClient.html#ae2bb48a9ab6d1a8dc80618192527dc4b',1,'NTPClient']]],
  ['lastsyncd_1',['lastSyncd',['../classNTPClient.html#acf88f9251f0fc0aa913c07a43c98ebb0',1,'NTPClient']]],
  ['led_5fbuiltin_2',['LED_BUILTIN',['../ledFlasher_8cpp.html#a450a7c16ead7b3c7b882536b08f30a00',1,'ledFlasher.cpp']]],
  ['ledflasher_2ecpp_3',['ledFlasher.cpp',['../ledFlasher_8cpp.html',1,'']]],
  ['li_4',['li',['../structNTPFlags__t.html#a0beb198b9227ad7dd22b47d5cda1baa9',1,'NTPFlags_t']]],
  ['license_5',['LICENSE',['../md_LICENSE.html',1,'']]],
  ['license_2emd_6',['LICENSE.md',['../LICENSE_8md.html',1,'']]],
  ['longinterval_7',['longInterval',['../classNTPClient.html#a4ec812a51fa11876ada81ba7ab24b123',1,'NTPClient']]],
  ['loop_8',['loop',['../advancedExample_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'loop():&#160;advancedExample.cpp'],['../basicExample_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'loop():&#160;basicExample.cpp'],['../ledFlasher_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'loop():&#160;ledFlasher.cpp'],['../main_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'loop():&#160;main.cpp']]],
  ['looptimer_9',['loopTimer',['../classNTPClient.html#a317c58e4e14c6c79db2f750f97b6928b',1,'NTPClient']]]
];
