var searchData=
[
  ['valid_0',['valid',['../structNTPPacket__t.html#a87dd0e76a5f74d5f2c6764f89af59547',1,'NTPPacket_t']]],
  ['vers_1',['vers',['../structNTPFlags__t.html#a346263c32b7effb69319b20438d08984',1,'NTPFlags_t']]]
];
