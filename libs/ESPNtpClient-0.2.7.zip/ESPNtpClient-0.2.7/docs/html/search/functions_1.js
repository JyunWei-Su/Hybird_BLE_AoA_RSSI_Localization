var searchData=
[
  ['adjustoffset_0',['adjustOffset',['../classNTPClient.html#a46adccfa3280ec52132bb2ceb9499567',1,'NTPClient']]]
];
