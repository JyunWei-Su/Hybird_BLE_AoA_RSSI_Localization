/*
 * I2CACVersion.h
 *
 *  Created on: Mar 28, 2018
 *      Author: chris.l
 */

#ifndef I2CACVERSION_H_
#define I2CACVERSION_H_

#define I2C_ANALOG_CLOCK_VERSION 1

#endif /* I2CACVERSION_H_ */
