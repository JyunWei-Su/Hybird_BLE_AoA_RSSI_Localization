/*
 * Ping.cpp
 *
 *  Created on: Jul 7, 2017
 *      Author: chris.l
 */

#include "Ping.h"

Ping::Ping()
{
    // TODO Auto-generated constructor stub

}

