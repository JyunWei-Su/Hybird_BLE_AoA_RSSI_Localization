/*
 * IPAddress.cpp
 *
 *  Created on: Jul 7, 2017
 *      Author: chris.l
 */

#include "IPAddress.h"

IPAddress::IPAddress()
{
    // TODO Auto-generated constructor stub

}

