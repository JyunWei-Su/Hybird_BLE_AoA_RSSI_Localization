/*
 * Ping.h
 *
 *  Created on: Jul 7, 2017
 *      Author: chris.l
 */

#ifndef PING_H_
#define PING_H_
#include "Arduino.h"

class Ping
{
public:
    Ping();
    void ping(IPAddress address) {
    }
};

#endif /* PING_H_ */
